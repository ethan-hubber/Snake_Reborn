//keys - name,age...
//values - eitan,25...
var mydata = {
"name":"eitan",
"age":"25",
"instrument":"piano"

}
console.log(mydata["name "]+Object.keys(mydata))