
//What is the best score?
// function getBestScore(data){
//     let minprice = 350;
//     let name = "Test";
//     for (let i = 0; i < data.length; i++){
//         if ( data[i]["price"] !== null && data[i]["price"] < minprice){
//             minprice = data[i]["price"];
//             name = data[i]["title"];
//         }
//     }
//     return name;
// }


// module.exports = {

//     getBestScore,
// };